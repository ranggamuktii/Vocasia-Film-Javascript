const tampilkanFilmDenganKategori = (filmKategori, judulKategori) => {
  if (filmKategori.length > 0) {
    const kategoriElement = `
        <section class="garis-metode">
            <section class="garis"></section>
            <h3>${judulKategori}</h3>
            <section class="garis"></section>
        </section>
      `;
    versiFilmContainer.innerHTML += kategoriElement;
    tampilkanDataFilm(filmKategori);
  }
};

/* nav {
    width: 100%;
    position: fixed;
    top: 0;
    padding: 15px 0px;
    background-color: #ffff;
    text-decoration: none;
    box-sizing: border-box;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    z-index: 1;
}

.navdiv {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1450px;
    margin: 0 auto;
}

nav .logo a img {
    width: 150px;
}

ul li {
    list-style: none;
    display: inline-block;
    margin-right: 20px;
    padding: 10px;
    border-radius: 10px;
    box-sizing: border-box;
}

ul li:hover {
    background-color: #f1f1f1;
}

ul li:last-child {
    margin-right: 0;
}

li a {
    color: #111111;
    font-size: 16px;
    font-weight: 500;
    text-decoration: none;
} */
